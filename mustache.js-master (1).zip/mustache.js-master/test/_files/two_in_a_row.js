({
  name: 'Joe',
  greeting: 'Welcome'
});
