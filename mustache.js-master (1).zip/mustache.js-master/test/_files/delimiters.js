({
  first: 'It worked the first time.',
  second: 'And it worked the second time.',
  third: 'Then, surprisingly, it worked the third time.',
  fourth: 'Fourth time also fine!.'
});
